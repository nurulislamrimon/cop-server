# cop-server

## This server is for co-operative organisation.

### Read: [the doc](https://docs.google.com/document/d/1ys2TfHhnZZNF_n8kAk1zAmxzE5wUn3Iam4hgAH1RJjk/edit?usp=sharing) to know about this server.

### visit the [site](https://cop-server-nirimonpc-gmailcom.vercel.app/) to live preview.

`Hi there,`
I am Nurul Islam Rimon. I am a MERN Stack Developer. I have an organization where we have **40+ members**.
We have administration team to lead and manage the organization. Last year our revenue was 32%. It was very defficult to mantain the account. So, I have developed the Site for the organization. Now it makes our management so easy.

## Technologies:

- Nodejs
- Expressjs
- MongoDB (with aggregation)
- Mongoose

### Complex operation

- Calculation of balance
- Investments theory
- Closing Business
- Profits distributions
