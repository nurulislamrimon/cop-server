exports.adminToManager = [
  "admin",
  "chairman",
  "vice-chairman",
  "director",
  "managing-director",
  "manager",
];
exports.adminToManagerAndGeneralMember = [
  "admin",
  "chairman",
  "vice-chairman",
  "director",
  "managing-director",
  "manager",
  "general-member",
];
exports.adminToManagerAndCollector = [
  "admin",
  "chairman",
  "vice-chairman",
  "director",
  "managing-director",
  "manager",
  "collector",
];
